#include "Lab1.h"

int main(void) {

	task_1();
	//task_2();
	//task_3();
	//task_4();

	return 0;
}